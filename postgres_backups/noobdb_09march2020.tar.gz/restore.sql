--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12
-- Dumped by pg_dump version 10.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.products_waitlist DROP CONSTRAINT products_waitlist_user_id_id_2344f6b7_fk_auth_user_id;
ALTER TABLE ONLY public.products_waitlist DROP CONSTRAINT products_waitlist_prod_id_id_ea68e7c0_fk_products_product_id;
ALTER TABLE ONLY public.products_usercode DROP CONSTRAINT products_usercode_user_id_id_9cc4f24a_fk_auth_user_id;
ALTER TABLE ONLY public.products_thumbnail DROP CONSTRAINT products_thumbnail_img_id_id_a88b3ecf_fk_products_image_id;
ALTER TABLE ONLY public.products_tags DROP CONSTRAINT products_tags_parent_id_a3c5d9ad_fk_products_tags_id;
ALTER TABLE ONLY public.products_similarproducts DROP CONSTRAINT products_similarprod_sim_id_id_7eeff2e7_fk_products_;
ALTER TABLE ONLY public.products_similarproducts DROP CONSTRAINT products_similarprod_prod_id_id_b3f0174c_fk_products_;
ALTER TABLE ONLY public.products_shoplinks DROP CONSTRAINT products_shoplinks_tag_id_id_2825f4d4_fk_products_tags_id;
ALTER TABLE ONLY public.products_shoplinks DROP CONSTRAINT products_shoplinks_breadcrumb_id_a0a784d0_fk_products_;
ALTER TABLE ONLY public.products_relatedproducts DROP CONSTRAINT products_relatedprod_sim_id_id_e54af4e0_fk_products_;
ALTER TABLE ONLY public.products_relatedproducts DROP CONSTRAINT products_relatedprod_prod_id_id_3572e434_fk_products_;
ALTER TABLE ONLY public.products_referalpricelist DROP CONSTRAINT products_referalpric_prod_id_id_d4c63e23_fk_products_;
ALTER TABLE ONLY public.products_referalpricelist DROP CONSTRAINT products_referalpric_code_id_id_e96f2872_fk_products_;
ALTER TABLE ONLY public.products_razorpayhistory DROP CONSTRAINT products_razorpayhistory_user_id_id_c4e067c9_fk_auth_user_id;
ALTER TABLE ONLY public.products_producttags DROP CONSTRAINT products_producttags_tag_id_id_69ac9e9f_fk_products_tags_id;
ALTER TABLE ONLY public.products_producttags DROP CONSTRAINT products_producttags_prod_id_id_1f91c29d_fk_products_product_id;
ALTER TABLE ONLY public.products_productlinks DROP CONSTRAINT products_productlink_prod_id_id_31f270cf_fk_products_;
ALTER TABLE ONLY public.products_productlinks DROP CONSTRAINT products_productlink_link_id_id_16c5ee0c_fk_products_;
ALTER TABLE ONLY public.products_productkeywords DROP CONSTRAINT products_productkeyw_prod_id_id_f69ce25a_fk_products_;
ALTER TABLE ONLY public.products_productkeywords DROP CONSTRAINT products_productkeyw_keytag_id_id_6a103f7d_fk_products_;
ALTER TABLE ONLY public.products_productdetails DROP CONSTRAINT products_productdeta_prod_id_id_72d3b635_fk_products_;
ALTER TABLE ONLY public.products_productbullets DROP CONSTRAINT products_productbull_prod_id_id_f69ad6ec_fk_products_;
ALTER TABLE ONLY public.products_product DROP CONSTRAINT products_product_breadcrumb_id_c7b8d6a3_fk_products_;
ALTER TABLE ONLY public.products_paytmhistory DROP CONSTRAINT products_paytmhistory_user_id_id_bc56ddcf_fk_auth_user_id;
ALTER TABLE ONLY public.products_orders DROP CONSTRAINT products_orders_user_id_id_44d0b3dd_fk_auth_user_id;
ALTER TABLE ONLY public.products_orderproducts DROP CONSTRAINT products_orderproduc_prod_id_id_7714df9b_fk_products_;
ALTER TABLE ONLY public.products_orderproducts DROP CONSTRAINT products_orderproduc_order_id_id_69779bb8_fk_products_;
ALTER TABLE ONLY public.products_mainimage DROP CONSTRAINT products_mainimage_thumb_data_id_356b1162_fk_products_;
ALTER TABLE ONLY public.products_mainimage DROP CONSTRAINT products_mainimage_prod_id_id_d70cc8d6_fk_products_product_id;
ALTER TABLE ONLY public.products_mainimage DROP CONSTRAINT products_mainimage_img_data_id_5808a737_fk_products_;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_th_mini_id_7608c9c9_fk_products_thumbnail_id;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_th_micro_id_cff4fc99_fk_products_;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_th_home_id_e22c98fe_fk_products_thumbnail_id;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_prod_id_id_d763bcc2_fk_products_product_id;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_img_id_id_c2864f2f_fk_products_image_id;
ALTER TABLE ONLY public.products_image DROP CONSTRAINT products_image_prod_id_id_c2143108_fk_products_product_id;
ALTER TABLE ONLY public.products_homepage DROP CONSTRAINT products_homepage_prod_id_id_e7f94b86_fk_products_product_id;
ALTER TABLE ONLY public.products_forgorpwdlink DROP CONSTRAINT products_forgorpwdlink_user_id_id_dcb662b7_fk_auth_user_id;
ALTER TABLE ONLY public.products_cartobjects DROP CONSTRAINT products_cartobjects_prod_id_id_47afcb53_fk_products_product_id;
ALTER TABLE ONLY public.products_cartobjects DROP CONSTRAINT products_cartobjects_cart_id_id_3e624781_fk_products_cart_id;
ALTER TABLE ONLY public.products_cart DROP CONSTRAINT products_cart_user_id_id_b1d3270d_fk_auth_user_id;
ALTER TABLE ONLY public.products_cart DROP CONSTRAINT products_cart_referal_obj_id_09c8c88b_fk_products_;
ALTER TABLE ONLY public.products_breadentry DROP CONSTRAINT products_breadentry_link_id_id_b5071704_fk_products_;
ALTER TABLE ONLY public.products_breadentry DROP CONSTRAINT products_breadentry_bread_id_id_5c54599d_fk_products_;
ALTER TABLE ONLY public.products_blogphotos DROP CONSTRAINT products_blogphotos_blog_id_id_094c32b3_fk_products_blog_id;
ALTER TABLE ONLY public.lazysignup_lazyuser DROP CONSTRAINT lazysignup_lazyuser_user_id_4030eee4_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE ONLY public.background_task DROP CONSTRAINT background_task_creator_content_type_61cc9af3_fk_django_co;
ALTER TABLE ONLY public.background_task_completedtask DROP CONSTRAINT background_task_comp_creator_content_type_21d6a741_fk_django_co;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX public.products_zipcodes_zipcode_21e8128c_like;
DROP INDEX public.products_waitlist_user_id_id_2344f6b7;
DROP INDEX public.products_waitlist_prod_id_id_ea68e7c0;
DROP INDEX public.products_thumbnail_img_id_id_a88b3ecf;
DROP INDEX public.products_tags_parent_id_a3c5d9ad;
DROP INDEX public.products_similarproducts_sim_id_id_7eeff2e7;
DROP INDEX public.products_similarproducts_prod_id_id_b3f0174c;
DROP INDEX public.products_shoplinks_url_e4f6bc4c_like;
DROP INDEX public.products_shoplinks_tag_id_id_2825f4d4;
DROP INDEX public.products_shoplinks_breadcrumb_id_a0a784d0;
DROP INDEX public.products_relatedproducts_sim_id_id_e54af4e0;
DROP INDEX public.products_relatedproducts_prod_id_id_3572e434;
DROP INDEX public.products_referalpricelist_prod_id_id_d4c63e23;
DROP INDEX public.products_referalpricelist_code_id_id_e96f2872;
DROP INDEX public.products_referalcodes_code_f83351aa_like;
DROP INDEX public.products_razorpayhistory_user_id_id_c4e067c9;
DROP INDEX public.products_producttags_tag_id_id_69ac9e9f;
DROP INDEX public.products_producttags_prod_id_id_1f91c29d;
DROP INDEX public.products_productlinks_prod_id_id_31f270cf;
DROP INDEX public.products_productlinks_link_id_id_16c5ee0c;
DROP INDEX public.products_productkeywords_prod_id_id_f69ce25a;
DROP INDEX public.products_productkeywords_keytag_id_id_6a103f7d;
DROP INDEX public.products_productdetails_prod_id_id_72d3b635;
DROP INDEX public.products_productbullets_prod_id_id_f69ad6ec;
DROP INDEX public.products_product_slug_70d3148d_like;
DROP INDEX public.products_product_sku_3c51a516_like;
DROP INDEX public.products_product_breadcrumb_id_c7b8d6a3;
DROP INDEX public.products_paytmhistory_user_id_id_bc56ddcf;
DROP INDEX public.products_orders_user_id_id_44d0b3dd;
DROP INDEX public.products_orders_order_id_b28e1457_like;
DROP INDEX public.products_orderproducts_prod_id_id_7714df9b;
DROP INDEX public.products_orderproducts_order_id_id_69779bb8;
DROP INDEX public.products_mainimage_thumb_data_id_356b1162;
DROP INDEX public.products_mainimage_img_data_id_5808a737;
DROP INDEX public.products_keywordtags_name_d777d86d_like;
DROP INDEX public.products_imagedata_th_mini_id_7608c9c9;
DROP INDEX public.products_imagedata_th_micro_id_cff4fc99;
DROP INDEX public.products_imagedata_th_home_id_e22c98fe;
DROP INDEX public.products_imagedata_prod_id_id_d763bcc2;
DROP INDEX public.products_image_prod_id_id_c2143108;
DROP INDEX public.products_forgorpwdlink_user_id_id_dcb662b7;
DROP INDEX public.products_cartobjects_prod_id_id_47afcb53;
DROP INDEX public.products_cartobjects_cart_id_id_3e624781;
DROP INDEX public.products_cart_referal_obj_id_09c8c88b;
DROP INDEX public.products_breadentry_link_id_id_b5071704;
DROP INDEX public.products_breadentry_bread_id_id_5c54599d;
DROP INDEX public.products_blogphotos_blog_id_id_094c32b3;
DROP INDEX public.products_blog_slug_2fa9d169_like;
DROP INDEX public.myapp_downloadsmodel_slug_74439d67_like;
DROP INDEX public.lazysignup_lazyuser_created_fcd322b5;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
DROP INDEX public.django_admin_log_user_id_c564eba6;
DROP INDEX public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX public.background_task_task_name_4562d56a_like;
DROP INDEX public.background_task_task_name_4562d56a;
DROP INDEX public.background_task_task_hash_d8f233bd_like;
DROP INDEX public.background_task_task_hash_d8f233bd;
DROP INDEX public.background_task_run_at_7baca3aa;
DROP INDEX public.background_task_queue_1d5f3a40_like;
DROP INDEX public.background_task_queue_1d5f3a40;
DROP INDEX public.background_task_priority_88bdbce9;
DROP INDEX public.background_task_locked_by_db7779e3_like;
DROP INDEX public.background_task_locked_by_db7779e3;
DROP INDEX public.background_task_locked_at_0fb0f225;
DROP INDEX public.background_task_failed_at_b81bba14;
DROP INDEX public.background_task_creator_content_type_id_61cc9af3;
DROP INDEX public.background_task_completedtask_task_name_388dabc2_like;
DROP INDEX public.background_task_completedtask_task_name_388dabc2;
DROP INDEX public.background_task_completedtask_task_hash_91187576_like;
DROP INDEX public.background_task_completedtask_task_hash_91187576;
DROP INDEX public.background_task_completedtask_run_at_77c80f34;
DROP INDEX public.background_task_completedtask_queue_61fb0415_like;
DROP INDEX public.background_task_completedtask_queue_61fb0415;
DROP INDEX public.background_task_completedtask_priority_9080692e;
DROP INDEX public.background_task_completedtask_locked_by_edc8a213_like;
DROP INDEX public.background_task_completedtask_locked_by_edc8a213;
DROP INDEX public.background_task_completedtask_locked_at_29c62708;
DROP INDEX public.background_task_completedtask_failed_at_3de56618;
DROP INDEX public.background_task_completedtask_creator_content_type_id_21d6a741;
DROP INDEX public.background_task_completedtask_attempts_772a6783;
DROP INDEX public.background_task_attempts_a9ade23d;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX public.auth_user_groups_group_id_97559544;
DROP INDEX public.auth_permission_content_type_id_2f476e4b;
DROP INDEX public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.products_zipcodes DROP CONSTRAINT products_zipcodes_zipcode_key;
ALTER TABLE ONLY public.products_zipcodes DROP CONSTRAINT products_zipcodes_pkey;
ALTER TABLE ONLY public.products_waitlist DROP CONSTRAINT products_waitlist_pkey;
ALTER TABLE ONLY public.products_usercode DROP CONSTRAINT products_usercode_user_id_id_key;
ALTER TABLE ONLY public.products_usercode DROP CONSTRAINT products_usercode_pkey;
ALTER TABLE ONLY public.products_thumbnail DROP CONSTRAINT products_thumbnail_pkey;
ALTER TABLE ONLY public.products_tags DROP CONSTRAINT products_tags_pkey;
ALTER TABLE ONLY public.products_similarproducts DROP CONSTRAINT products_similarproducts_pkey;
ALTER TABLE ONLY public.products_shoplinks DROP CONSTRAINT products_shoplinks_url_key;
ALTER TABLE ONLY public.products_shoplinks DROP CONSTRAINT products_shoplinks_pkey;
ALTER TABLE ONLY public.products_relatedproducts DROP CONSTRAINT products_relatedproducts_pkey;
ALTER TABLE ONLY public.products_referalpricelist DROP CONSTRAINT products_referalpricelist_pkey;
ALTER TABLE ONLY public.products_referalcodes DROP CONSTRAINT products_referalcodes_pkey;
ALTER TABLE ONLY public.products_referalcodes DROP CONSTRAINT products_referalcodes_code_key;
ALTER TABLE ONLY public.products_razorpayhistory DROP CONSTRAINT products_razorpayhistory_pkey;
ALTER TABLE ONLY public.products_razopayidmaps DROP CONSTRAINT products_razopayidmaps_pkey;
ALTER TABLE ONLY public.products_producttags DROP CONSTRAINT products_producttags_prod_id_id_tag_id_id_4fd493b9_uniq;
ALTER TABLE ONLY public.products_producttags DROP CONSTRAINT products_producttags_pkey;
ALTER TABLE ONLY public.products_productlinks DROP CONSTRAINT products_productlinks_pkey;
ALTER TABLE ONLY public.products_productkeywords DROP CONSTRAINT products_productkeywords_prod_id_id_keytag_id_id_22ef94d0_uniq;
ALTER TABLE ONLY public.products_productkeywords DROP CONSTRAINT products_productkeywords_pkey;
ALTER TABLE ONLY public.products_productdetails DROP CONSTRAINT products_productdetails_pkey;
ALTER TABLE ONLY public.products_productbullets DROP CONSTRAINT products_productbullets_pkey;
ALTER TABLE ONLY public.products_product DROP CONSTRAINT products_product_slug_key;
ALTER TABLE ONLY public.products_product DROP CONSTRAINT products_product_sku_key;
ALTER TABLE ONLY public.products_product DROP CONSTRAINT products_product_pkey;
ALTER TABLE ONLY public.products_paytmhistory DROP CONSTRAINT products_paytmhistory_pkey;
ALTER TABLE ONLY public.products_orders DROP CONSTRAINT products_orders_pkey;
ALTER TABLE ONLY public.products_orders DROP CONSTRAINT products_orders_order_id_key;
ALTER TABLE ONLY public.products_orderproducts DROP CONSTRAINT products_orderproducts_pkey;
ALTER TABLE ONLY public.products_mainimage DROP CONSTRAINT products_mainimage_prod_id_id_key;
ALTER TABLE ONLY public.products_mainimage DROP CONSTRAINT products_mainimage_pkey;
ALTER TABLE ONLY public.products_keywordtags DROP CONSTRAINT products_keywordtags_pkey;
ALTER TABLE ONLY public.products_keywordtags DROP CONSTRAINT products_keywordtags_name_d777d86d_uniq;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_pkey;
ALTER TABLE ONLY public.products_imagedata DROP CONSTRAINT products_imagedata_img_id_id_key;
ALTER TABLE ONLY public.products_image DROP CONSTRAINT products_image_pkey;
ALTER TABLE ONLY public.products_homepage DROP CONSTRAINT products_homepage_prod_id_id_key;
ALTER TABLE ONLY public.products_homepage DROP CONSTRAINT products_homepage_pkey;
ALTER TABLE ONLY public.products_forgorpwdlink DROP CONSTRAINT products_forgorpwdlink_pkey;
ALTER TABLE ONLY public.products_cartobjects DROP CONSTRAINT products_cartobjects_pkey;
ALTER TABLE ONLY public.products_cart DROP CONSTRAINT products_cart_user_id_id_key;
ALTER TABLE ONLY public.products_cart DROP CONSTRAINT products_cart_pkey;
ALTER TABLE ONLY public.products_breadentry DROP CONSTRAINT products_breadentry_pkey;
ALTER TABLE ONLY public.products_breadcrumbs DROP CONSTRAINT products_breadcrumbs_pkey;
ALTER TABLE ONLY public.products_blogphotos DROP CONSTRAINT products_blogphotos_pkey;
ALTER TABLE ONLY public.products_blog DROP CONSTRAINT products_blog_slug_key;
ALTER TABLE ONLY public.products_blog DROP CONSTRAINT products_blog_pkey;
ALTER TABLE ONLY public.myapp_downloadsmodel DROP CONSTRAINT myapp_downloadsmodel_slug_key;
ALTER TABLE ONLY public.myapp_downloadsmodel DROP CONSTRAINT myapp_downloadsmodel_pkey;
ALTER TABLE ONLY public.lazysignup_lazyuser DROP CONSTRAINT lazysignup_lazyuser_user_id_key;
ALTER TABLE ONLY public.lazysignup_lazyuser DROP CONSTRAINT lazysignup_lazyuser_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.background_task DROP CONSTRAINT background_task_pkey;
ALTER TABLE ONLY public.background_task_completedtask DROP CONSTRAINT background_task_completedtask_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.products_zipcodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_waitlist ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_usercode ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_thumbnail ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_similarproducts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_shoplinks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_relatedproducts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_referalpricelist ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_referalcodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_razorpayhistory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_razopayidmaps ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_producttags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_productlinks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_productkeywords ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_productdetails ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_productbullets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_product ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_paytmhistory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_orderproducts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_mainimage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_keywordtags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_imagedata ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_image ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_homepage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_forgorpwdlink ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_cartobjects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_cart ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_breadentry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_breadcrumbs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_blogphotos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products_blog ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.myapp_downloadsmodel ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lazysignup_lazyuser ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.background_task_completedtask ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.background_task ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.products_zipcodes_id_seq;
DROP TABLE public.products_zipcodes;
DROP SEQUENCE public.products_waitlist_id_seq;
DROP TABLE public.products_waitlist;
DROP SEQUENCE public.products_usercode_id_seq;
DROP TABLE public.products_usercode;
DROP SEQUENCE public.products_thumbnail_id_seq;
DROP TABLE public.products_thumbnail;
DROP SEQUENCE public.products_tags_id_seq;
DROP TABLE public.products_tags;
DROP SEQUENCE public.products_similarproducts_id_seq;
DROP TABLE public.products_similarproducts;
DROP SEQUENCE public.products_shoplinks_id_seq;
DROP TABLE public.products_shoplinks;
DROP SEQUENCE public.products_relatedproducts_id_seq;
DROP TABLE public.products_relatedproducts;
DROP SEQUENCE public.products_referalpricelist_id_seq;
DROP TABLE public.products_referalpricelist;
DROP SEQUENCE public.products_referalcodes_id_seq;
DROP TABLE public.products_referalcodes;
DROP SEQUENCE public.products_razorpayhistory_id_seq;
DROP TABLE public.products_razorpayhistory;
DROP SEQUENCE public.products_razopayidmaps_id_seq;
DROP TABLE public.products_razopayidmaps;
DROP SEQUENCE public.products_producttags_id_seq;
DROP TABLE public.products_producttags;
DROP SEQUENCE public.products_productlinks_id_seq;
DROP TABLE public.products_productlinks;
DROP SEQUENCE public.products_productkeywords_id_seq;
DROP TABLE public.products_productkeywords;
DROP SEQUENCE public.products_productdetails_id_seq;
DROP TABLE public.products_productdetails;
DROP SEQUENCE public.products_productbullets_id_seq;
DROP TABLE public.products_productbullets;
DROP SEQUENCE public.products_product_id_seq;
DROP TABLE public.products_product;
DROP SEQUENCE public.products_paytmhistory_id_seq;
DROP TABLE public.products_paytmhistory;
DROP SEQUENCE public.products_orders_id_seq;
DROP TABLE public.products_orders;
DROP SEQUENCE public.products_orderproducts_id_seq;
DROP TABLE public.products_orderproducts;
DROP SEQUENCE public.products_mainimage_id_seq;
DROP TABLE public.products_mainimage;
DROP SEQUENCE public.products_keywordtags_id_seq;
DROP TABLE public.products_keywordtags;
DROP SEQUENCE public.products_imagedata_id_seq;
DROP TABLE public.products_imagedata;
DROP SEQUENCE public.products_image_id_seq;
DROP TABLE public.products_image;
DROP SEQUENCE public.products_homepage_id_seq;
DROP TABLE public.products_homepage;
DROP SEQUENCE public.products_forgorpwdlink_id_seq;
DROP TABLE public.products_forgorpwdlink;
DROP SEQUENCE public.products_cartobjects_id_seq;
DROP TABLE public.products_cartobjects;
DROP SEQUENCE public.products_cart_id_seq;
DROP TABLE public.products_cart;
DROP SEQUENCE public.products_breadentry_id_seq;
DROP TABLE public.products_breadentry;
DROP SEQUENCE public.products_breadcrumbs_id_seq;
DROP TABLE public.products_breadcrumbs;
DROP SEQUENCE public.products_blogphotos_id_seq;
DROP TABLE public.products_blogphotos;
DROP SEQUENCE public.products_blog_id_seq;
DROP TABLE public.products_blog;
DROP SEQUENCE public.myapp_downloadsmodel_id_seq;
DROP TABLE public.myapp_downloadsmodel;
DROP SEQUENCE public.lazysignup_lazyuser_id_seq;
DROP TABLE public.lazysignup_lazyuser;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.background_task_id_seq;
DROP SEQUENCE public.background_task_completedtask_id_seq;
DROP TABLE public.background_task_completedtask;
DROP TABLE public.background_task;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO noobuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO noobuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO noobuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO noobuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO noobuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO noobuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO noobuser;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO noobuser;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO noobuser;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO noobuser;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO noobuser;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO noobuser;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: background_task; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.background_task (
    id integer NOT NULL,
    task_name character varying(190) NOT NULL,
    task_params text NOT NULL,
    task_hash character varying(40) NOT NULL,
    verbose_name character varying(255),
    priority integer NOT NULL,
    run_at timestamp with time zone NOT NULL,
    repeat bigint NOT NULL,
    repeat_until timestamp with time zone,
    queue character varying(190),
    attempts integer NOT NULL,
    failed_at timestamp with time zone,
    last_error text NOT NULL,
    locked_by character varying(64),
    locked_at timestamp with time zone,
    creator_object_id integer,
    creator_content_type_id integer,
    CONSTRAINT background_task_creator_object_id_check CHECK ((creator_object_id >= 0))
);


ALTER TABLE public.background_task OWNER TO noobuser;

--
-- Name: background_task_completedtask; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.background_task_completedtask (
    id integer NOT NULL,
    task_name character varying(190) NOT NULL,
    task_params text NOT NULL,
    task_hash character varying(40) NOT NULL,
    verbose_name character varying(255),
    priority integer NOT NULL,
    run_at timestamp with time zone NOT NULL,
    repeat bigint NOT NULL,
    repeat_until timestamp with time zone,
    queue character varying(190),
    attempts integer NOT NULL,
    failed_at timestamp with time zone,
    last_error text NOT NULL,
    locked_by character varying(64),
    locked_at timestamp with time zone,
    creator_object_id integer,
    creator_content_type_id integer,
    CONSTRAINT background_task_completedtask_creator_object_id_check CHECK ((creator_object_id >= 0))
);


ALTER TABLE public.background_task_completedtask OWNER TO noobuser;

--
-- Name: background_task_completedtask_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.background_task_completedtask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.background_task_completedtask_id_seq OWNER TO noobuser;

--
-- Name: background_task_completedtask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.background_task_completedtask_id_seq OWNED BY public.background_task_completedtask.id;


--
-- Name: background_task_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.background_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.background_task_id_seq OWNER TO noobuser;

--
-- Name: background_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.background_task_id_seq OWNED BY public.background_task.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO noobuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO noobuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO noobuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO noobuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO noobuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO noobuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO noobuser;

--
-- Name: lazysignup_lazyuser; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.lazysignup_lazyuser (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.lazysignup_lazyuser OWNER TO noobuser;

--
-- Name: lazysignup_lazyuser_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.lazysignup_lazyuser_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lazysignup_lazyuser_id_seq OWNER TO noobuser;

--
-- Name: lazysignup_lazyuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.lazysignup_lazyuser_id_seq OWNED BY public.lazysignup_lazyuser.id;


--
-- Name: myapp_downloadsmodel; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.myapp_downloadsmodel (
    id integer NOT NULL,
    slug character varying(100) NOT NULL,
    title character varying(500) NOT NULL,
    big_title character varying(500) NOT NULL,
    windows_link character varying(500) NOT NULL,
    ubuntu_link character varying(500) NOT NULL,
    mac_link character varying(500) NOT NULL,
    updated timestamp with time zone NOT NULL,
    created timestamp with time zone NOT NULL
);


ALTER TABLE public.myapp_downloadsmodel OWNER TO noobuser;

--
-- Name: myapp_downloadsmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.myapp_downloadsmodel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.myapp_downloadsmodel_id_seq OWNER TO noobuser;

--
-- Name: myapp_downloadsmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.myapp_downloadsmodel_id_seq OWNED BY public.myapp_downloadsmodel.id;


--
-- Name: products_blog; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_blog (
    id integer NOT NULL,
    slug character varying(1500) NOT NULL,
    name text NOT NULL,
    markdown text NOT NULL,
    html text NOT NULL,
    short_html text NOT NULL,
    short_markdown text NOT NULL,
    description text NOT NULL,
    rank integer NOT NULL,
    is_published boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    keywords text NOT NULL
);


ALTER TABLE public.products_blog OWNER TO noobuser;

--
-- Name: products_blog_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_blog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_blog_id_seq OWNER TO noobuser;

--
-- Name: products_blog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_blog_id_seq OWNED BY public.products_blog.id;


--
-- Name: products_blogphotos; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_blogphotos (
    id integer NOT NULL,
    image character varying(1000) NOT NULL,
    created timestamp with time zone NOT NULL,
    blog_id_id integer NOT NULL,
    main_image boolean NOT NULL
);


ALTER TABLE public.products_blogphotos OWNER TO noobuser;

--
-- Name: products_blogphotos_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_blogphotos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_blogphotos_id_seq OWNER TO noobuser;

--
-- Name: products_blogphotos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_blogphotos_id_seq OWNED BY public.products_blogphotos.id;


--
-- Name: products_breadcrumbs; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_breadcrumbs (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    google_product_taxonomy character varying(400) NOT NULL
);


ALTER TABLE public.products_breadcrumbs OWNER TO noobuser;

--
-- Name: products_breadcrumbs_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_breadcrumbs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_breadcrumbs_id_seq OWNER TO noobuser;

--
-- Name: products_breadcrumbs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_breadcrumbs_id_seq OWNED BY public.products_breadcrumbs.id;


--
-- Name: products_breadentry; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_breadentry (
    id integer NOT NULL,
    rank integer NOT NULL,
    created timestamp with time zone NOT NULL,
    bread_id_id integer NOT NULL,
    link_id_id integer NOT NULL
);


ALTER TABLE public.products_breadentry OWNER TO noobuser;

--
-- Name: products_breadentry_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_breadentry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_breadentry_id_seq OWNER TO noobuser;

--
-- Name: products_breadentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_breadentry_id_seq OWNED BY public.products_breadentry.id;


--
-- Name: products_cart; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_cart (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    cart_state character varying(3) NOT NULL,
    address_name character varying(100) NOT NULL,
    address1 character varying(100) NOT NULL,
    address2 character varying(100) NOT NULL,
    district character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    zipcode character varying(6) NOT NULL,
    mobile character varying(10) NOT NULL,
    paymode character varying(10),
    user_id_id integer NOT NULL,
    to_be_order_id character varying(20),
    payment_amount double precision NOT NULL,
    is_referal_activated boolean NOT NULL,
    referal_code character varying(20) NOT NULL,
    referal_obj_id integer,
    ip_data text NOT NULL,
    email_id character varying(100) NOT NULL
);


ALTER TABLE public.products_cart OWNER TO noobuser;

--
-- Name: products_cart_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_cart_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_cart_id_seq OWNER TO noobuser;

--
-- Name: products_cart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_cart_id_seq OWNED BY public.products_cart.id;


--
-- Name: products_cartobjects; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_cartobjects (
    id integer NOT NULL,
    quantity integer NOT NULL,
    created timestamp with time zone NOT NULL,
    cart_id_id integer NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_cartobjects OWNER TO noobuser;

--
-- Name: products_cartobjects_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_cartobjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_cartobjects_id_seq OWNER TO noobuser;

--
-- Name: products_cartobjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_cartobjects_id_seq OWNED BY public.products_cartobjects.id;


--
-- Name: products_forgorpwdlink; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_forgorpwdlink (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id_id integer NOT NULL
);


ALTER TABLE public.products_forgorpwdlink OWNER TO noobuser;

--
-- Name: products_forgorpwdlink_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_forgorpwdlink_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_forgorpwdlink_id_seq OWNER TO noobuser;

--
-- Name: products_forgorpwdlink_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_forgorpwdlink_id_seq OWNED BY public.products_forgorpwdlink.id;


--
-- Name: products_homepage; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_homepage (
    id integer NOT NULL,
    rank integer NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_homepage OWNER TO noobuser;

--
-- Name: products_homepage_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_homepage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_homepage_id_seq OWNER TO noobuser;

--
-- Name: products_homepage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_homepage_id_seq OWNED BY public.products_homepage.id;


--
-- Name: products_image; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_image (
    id integer NOT NULL,
    image character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_image OWNER TO noobuser;

--
-- Name: products_image_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_image_id_seq OWNER TO noobuser;

--
-- Name: products_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_image_id_seq OWNED BY public.products_image.id;


--
-- Name: products_imagedata; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_imagedata (
    id integer NOT NULL,
    rank integer NOT NULL,
    img_id_id integer NOT NULL,
    prod_id_id integer NOT NULL,
    th_home_id integer NOT NULL,
    th_micro_id integer NOT NULL,
    th_mini_id integer NOT NULL
);


ALTER TABLE public.products_imagedata OWNER TO noobuser;

--
-- Name: products_imagedata_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_imagedata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_imagedata_id_seq OWNER TO noobuser;

--
-- Name: products_imagedata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_imagedata_id_seq OWNED BY public.products_imagedata.id;


--
-- Name: products_keywordtags; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_keywordtags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    count integer NOT NULL
);


ALTER TABLE public.products_keywordtags OWNER TO noobuser;

--
-- Name: products_keywordtags_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_keywordtags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_keywordtags_id_seq OWNER TO noobuser;

--
-- Name: products_keywordtags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_keywordtags_id_seq OWNED BY public.products_keywordtags.id;


--
-- Name: products_mainimage; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_mainimage (
    id integer NOT NULL,
    img_data_id integer NOT NULL,
    prod_id_id integer NOT NULL,
    thumb_data_id integer NOT NULL
);


ALTER TABLE public.products_mainimage OWNER TO noobuser;

--
-- Name: products_mainimage_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_mainimage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_mainimage_id_seq OWNER TO noobuser;

--
-- Name: products_mainimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_mainimage_id_seq OWNED BY public.products_mainimage.id;


--
-- Name: products_orderproducts; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_orderproducts (
    id integer NOT NULL,
    quantity integer NOT NULL,
    price integer NOT NULL,
    order_id_id integer NOT NULL,
    prod_id_id integer
);


ALTER TABLE public.products_orderproducts OWNER TO noobuser;

--
-- Name: products_orderproducts_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_orderproducts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_orderproducts_id_seq OWNER TO noobuser;

--
-- Name: products_orderproducts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_orderproducts_id_seq OWNED BY public.products_orderproducts.id;


--
-- Name: products_orders; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_orders (
    id integer NOT NULL,
    order_id character varying(20) NOT NULL,
    created timestamp with time zone NOT NULL,
    order_state character varying(3) NOT NULL,
    paymode character varying(10) NOT NULL,
    delivery_charge integer NOT NULL,
    extra_charge integer NOT NULL,
    total_amount integer NOT NULL,
    courier character varying(100) NOT NULL,
    tracking_no character varying(100) NOT NULL,
    address_name character varying(100) NOT NULL,
    address1 character varying(100) NOT NULL,
    address2 character varying(100) NOT NULL,
    district character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    zipcode character varying(6) NOT NULL,
    mobile character varying(10) NOT NULL,
    user_id_id integer NOT NULL,
    email_sent_confirm boolean NOT NULL,
    email_sent_delivered boolean NOT NULL,
    email_sent_shipped boolean NOT NULL,
    referal_code character varying(20) NOT NULL,
    ip_data text NOT NULL,
    email_id character varying(100) NOT NULL
);


ALTER TABLE public.products_orders OWNER TO noobuser;

--
-- Name: products_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_orders_id_seq OWNER TO noobuser;

--
-- Name: products_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_orders_id_seq OWNED BY public.products_orders.id;


--
-- Name: products_paytmhistory; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_paytmhistory (
    id integer NOT NULL,
    txn_amount double precision NOT NULL,
    txn_date timestamp with time zone NOT NULL,
    txn_id character varying(400) NOT NULL,
    status character varying(40) NOT NULL,
    paytm_orderid character varying(40) NOT NULL,
    order_id character varying(40) NOT NULL,
    currency character varying(10) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id_id integer
);


ALTER TABLE public.products_paytmhistory OWNER TO noobuser;

--
-- Name: products_paytmhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_paytmhistory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_paytmhistory_id_seq OWNER TO noobuser;

--
-- Name: products_paytmhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_paytmhistory_id_seq OWNED BY public.products_paytmhistory.id;


--
-- Name: products_product; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_product (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    pagetitle character varying(200) NOT NULL,
    cardtitle character varying(200) NOT NULL,
    price integer NOT NULL,
    mrp_price integer NOT NULL,
    quantity_available integer NOT NULL,
    in_stock boolean NOT NULL,
    is_published boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    rank integer NOT NULL,
    updated timestamp with time zone NOT NULL,
    description text NOT NULL,
    sku character varying(8) NOT NULL,
    free_delivery boolean NOT NULL,
    amazon_link character varying(300) NOT NULL,
    is_amazon boolean NOT NULL,
    is_google boolean NOT NULL,
    meta_title text NOT NULL,
    product_head character varying(70) NOT NULL,
    breadcrumb_id integer,
    hide_description boolean NOT NULL,
    keywords text NOT NULL,
    hide_shop boolean NOT NULL,
    shopping_description text NOT NULL
);


ALTER TABLE public.products_product OWNER TO noobuser;

--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO noobuser;

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products_product.id;


--
-- Name: products_productbullets; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_productbullets (
    id integer NOT NULL,
    data character varying(100) NOT NULL,
    rank integer NOT NULL,
    created timestamp with time zone NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_productbullets OWNER TO noobuser;

--
-- Name: products_productbullets_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_productbullets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_productbullets_id_seq OWNER TO noobuser;

--
-- Name: products_productbullets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_productbullets_id_seq OWNED BY public.products_productbullets.id;


--
-- Name: products_productdetails; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_productdetails (
    id integer NOT NULL,
    rank integer NOT NULL,
    name character varying(50) NOT NULL,
    html text NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_productdetails OWNER TO noobuser;

--
-- Name: products_productdetails_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_productdetails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_productdetails_id_seq OWNER TO noobuser;

--
-- Name: products_productdetails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_productdetails_id_seq OWNED BY public.products_productdetails.id;


--
-- Name: products_productkeywords; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_productkeywords (
    id integer NOT NULL,
    rank integer NOT NULL,
    created timestamp with time zone NOT NULL,
    keytag_id_id integer NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_productkeywords OWNER TO noobuser;

--
-- Name: products_productkeywords_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_productkeywords_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_productkeywords_id_seq OWNER TO noobuser;

--
-- Name: products_productkeywords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_productkeywords_id_seq OWNED BY public.products_productkeywords.id;


--
-- Name: products_productlinks; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_productlinks (
    id integer NOT NULL,
    rank integer NOT NULL,
    created timestamp with time zone NOT NULL,
    link_id_id integer NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_productlinks OWNER TO noobuser;

--
-- Name: products_productlinks_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_productlinks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_productlinks_id_seq OWNER TO noobuser;

--
-- Name: products_productlinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_productlinks_id_seq OWNED BY public.products_productlinks.id;


--
-- Name: products_producttags; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_producttags (
    id integer NOT NULL,
    prod_id_id integer NOT NULL,
    tag_id_id integer NOT NULL
);


ALTER TABLE public.products_producttags OWNER TO noobuser;

--
-- Name: products_producttags_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_producttags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_producttags_id_seq OWNER TO noobuser;

--
-- Name: products_producttags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_producttags_id_seq OWNED BY public.products_producttags.id;


--
-- Name: products_razopayidmaps; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_razopayidmaps (
    id integer NOT NULL,
    rp_id character varying(100) NOT NULL,
    order_id character varying(50) NOT NULL,
    created timestamp with time zone NOT NULL
);


ALTER TABLE public.products_razopayidmaps OWNER TO noobuser;

--
-- Name: products_razopayidmaps_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_razopayidmaps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_razopayidmaps_id_seq OWNER TO noobuser;

--
-- Name: products_razopayidmaps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_razopayidmaps_id_seq OWNED BY public.products_razopayidmaps.id;


--
-- Name: products_razorpayhistory; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_razorpayhistory (
    id integer NOT NULL,
    order_id character varying(40) NOT NULL,
    txn_amount double precision NOT NULL,
    txn_date timestamp with time zone NOT NULL,
    status character varying(40) NOT NULL,
    details text NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id_id integer
);


ALTER TABLE public.products_razorpayhistory OWNER TO noobuser;

--
-- Name: products_razorpayhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_razorpayhistory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_razorpayhistory_id_seq OWNER TO noobuser;

--
-- Name: products_razorpayhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_razorpayhistory_id_seq OWNED BY public.products_razorpayhistory.id;


--
-- Name: products_referalcodes; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_referalcodes (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    is_active boolean NOT NULL,
    referer character varying(200) NOT NULL,
    details character varying(400) NOT NULL,
    is_shipping_free boolean NOT NULL,
    created timestamp with time zone NOT NULL
);


ALTER TABLE public.products_referalcodes OWNER TO noobuser;

--
-- Name: products_referalcodes_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_referalcodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_referalcodes_id_seq OWNER TO noobuser;

--
-- Name: products_referalcodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_referalcodes_id_seq OWNED BY public.products_referalcodes.id;


--
-- Name: products_referalpricelist; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_referalpricelist (
    id integer NOT NULL,
    price integer NOT NULL,
    moq integer NOT NULL,
    code_id_id integer NOT NULL,
    prod_id_id integer NOT NULL
);


ALTER TABLE public.products_referalpricelist OWNER TO noobuser;

--
-- Name: products_referalpricelist_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_referalpricelist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_referalpricelist_id_seq OWNER TO noobuser;

--
-- Name: products_referalpricelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_referalpricelist_id_seq OWNED BY public.products_referalpricelist.id;


--
-- Name: products_relatedproducts; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_relatedproducts (
    id integer NOT NULL,
    rank integer NOT NULL,
    prod_id_id integer NOT NULL,
    sim_id_id integer NOT NULL
);


ALTER TABLE public.products_relatedproducts OWNER TO noobuser;

--
-- Name: products_relatedproducts_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_relatedproducts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_relatedproducts_id_seq OWNER TO noobuser;

--
-- Name: products_relatedproducts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_relatedproducts_id_seq OWNED BY public.products_relatedproducts.id;


--
-- Name: products_shoplinks; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_shoplinks (
    id integer NOT NULL,
    url character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    tag_id_id integer NOT NULL,
    rank integer NOT NULL,
    meta_description character varying(200) NOT NULL,
    meta_title character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    breadcrumb_id integer
);


ALTER TABLE public.products_shoplinks OWNER TO noobuser;

--
-- Name: products_shoplinks_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_shoplinks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_shoplinks_id_seq OWNER TO noobuser;

--
-- Name: products_shoplinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_shoplinks_id_seq OWNED BY public.products_shoplinks.id;


--
-- Name: products_similarproducts; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_similarproducts (
    id integer NOT NULL,
    rank integer NOT NULL,
    prod_id_id integer NOT NULL,
    sim_id_id integer NOT NULL
);


ALTER TABLE public.products_similarproducts OWNER TO noobuser;

--
-- Name: products_similarproducts_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_similarproducts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_similarproducts_id_seq OWNER TO noobuser;

--
-- Name: products_similarproducts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_similarproducts_id_seq OWNED BY public.products_similarproducts.id;


--
-- Name: products_tags; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_tags (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    rank integer NOT NULL,
    type character varying(3) NOT NULL,
    is_standalone boolean NOT NULL,
    parent_id integer
);


ALTER TABLE public.products_tags OWNER TO noobuser;

--
-- Name: products_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_tags_id_seq OWNER TO noobuser;

--
-- Name: products_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_tags_id_seq OWNED BY public.products_tags.id;


--
-- Name: products_thumbnail; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_thumbnail (
    id integer NOT NULL,
    image character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    img_id_id integer NOT NULL
);


ALTER TABLE public.products_thumbnail OWNER TO noobuser;

--
-- Name: products_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_thumbnail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_thumbnail_id_seq OWNER TO noobuser;

--
-- Name: products_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_thumbnail_id_seq OWNED BY public.products_thumbnail.id;


--
-- Name: products_usercode; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_usercode (
    id integer NOT NULL,
    code character varying(10) NOT NULL,
    user_id_id integer NOT NULL,
    mobile character varying(10) NOT NULL,
    ip_data text NOT NULL
);


ALTER TABLE public.products_usercode OWNER TO noobuser;

--
-- Name: products_usercode_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_usercode_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_usercode_id_seq OWNER TO noobuser;

--
-- Name: products_usercode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_usercode_id_seq OWNED BY public.products_usercode.id;


--
-- Name: products_waitlist; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_waitlist (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    prod_id_id integer NOT NULL,
    user_id_id integer NOT NULL
);


ALTER TABLE public.products_waitlist OWNER TO noobuser;

--
-- Name: products_waitlist_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_waitlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_waitlist_id_seq OWNER TO noobuser;

--
-- Name: products_waitlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_waitlist_id_seq OWNED BY public.products_waitlist.id;


--
-- Name: products_zipcodes; Type: TABLE; Schema: public; Owner: noobuser
--

CREATE TABLE public.products_zipcodes (
    id integer NOT NULL,
    zipcode character varying(6) NOT NULL,
    district character varying(50) NOT NULL,
    state character varying(50) NOT NULL
);


ALTER TABLE public.products_zipcodes OWNER TO noobuser;

--
-- Name: products_zipcodes_id_seq; Type: SEQUENCE; Schema: public; Owner: noobuser
--

CREATE SEQUENCE public.products_zipcodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_zipcodes_id_seq OWNER TO noobuser;

--
-- Name: products_zipcodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: noobuser
--

ALTER SEQUENCE public.products_zipcodes_id_seq OWNED BY public.products_zipcodes.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: background_task id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.background_task ALTER COLUMN id SET DEFAULT nextval('public.background_task_id_seq'::regclass);


--
-- Name: background_task_completedtask id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.background_task_completedtask ALTER COLUMN id SET DEFAULT nextval('public.background_task_completedtask_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: lazysignup_lazyuser id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.lazysignup_lazyuser ALTER COLUMN id SET DEFAULT nextval('public.lazysignup_lazyuser_id_seq'::regclass);


--
-- Name: myapp_downloadsmodel id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.myapp_downloadsmodel ALTER COLUMN id SET DEFAULT nextval('public.myapp_downloadsmodel_id_seq'::regclass);


--
-- Name: products_blog id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_blog ALTER COLUMN id SET DEFAULT nextval('public.products_blog_id_seq'::regclass);


--
-- Name: products_blogphotos id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_blogphotos ALTER COLUMN id SET DEFAULT nextval('public.products_blogphotos_id_seq'::regclass);


--
-- Name: products_breadcrumbs id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_breadcrumbs ALTER COLUMN id SET DEFAULT nextval('public.products_breadcrumbs_id_seq'::regclass);


--
-- Name: products_breadentry id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_breadentry ALTER COLUMN id SET DEFAULT nextval('public.products_breadentry_id_seq'::regclass);


--
-- Name: products_cart id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cart ALTER COLUMN id SET DEFAULT nextval('public.products_cart_id_seq'::regclass);


--
-- Name: products_cartobjects id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cartobjects ALTER COLUMN id SET DEFAULT nextval('public.products_cartobjects_id_seq'::regclass);


--
-- Name: products_forgorpwdlink id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_forgorpwdlink ALTER COLUMN id SET DEFAULT nextval('public.products_forgorpwdlink_id_seq'::regclass);


--
-- Name: products_homepage id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_homepage ALTER COLUMN id SET DEFAULT nextval('public.products_homepage_id_seq'::regclass);


--
-- Name: products_image id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_image ALTER COLUMN id SET DEFAULT nextval('public.products_image_id_seq'::regclass);


--
-- Name: products_imagedata id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata ALTER COLUMN id SET DEFAULT nextval('public.products_imagedata_id_seq'::regclass);


--
-- Name: products_keywordtags id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_keywordtags ALTER COLUMN id SET DEFAULT nextval('public.products_keywordtags_id_seq'::regclass);


--
-- Name: products_mainimage id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_mainimage ALTER COLUMN id SET DEFAULT nextval('public.products_mainimage_id_seq'::regclass);


--
-- Name: products_orderproducts id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orderproducts ALTER COLUMN id SET DEFAULT nextval('public.products_orderproducts_id_seq'::regclass);


--
-- Name: products_orders id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orders ALTER COLUMN id SET DEFAULT nextval('public.products_orders_id_seq'::regclass);


--
-- Name: products_paytmhistory id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_paytmhistory ALTER COLUMN id SET DEFAULT nextval('public.products_paytmhistory_id_seq'::regclass);


--
-- Name: products_product id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_product ALTER COLUMN id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- Name: products_productbullets id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productbullets ALTER COLUMN id SET DEFAULT nextval('public.products_productbullets_id_seq'::regclass);


--
-- Name: products_productdetails id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productdetails ALTER COLUMN id SET DEFAULT nextval('public.products_productdetails_id_seq'::regclass);


--
-- Name: products_productkeywords id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productkeywords ALTER COLUMN id SET DEFAULT nextval('public.products_productkeywords_id_seq'::regclass);


--
-- Name: products_productlinks id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productlinks ALTER COLUMN id SET DEFAULT nextval('public.products_productlinks_id_seq'::regclass);


--
-- Name: products_producttags id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_producttags ALTER COLUMN id SET DEFAULT nextval('public.products_producttags_id_seq'::regclass);


--
-- Name: products_razopayidmaps id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_razopayidmaps ALTER COLUMN id SET DEFAULT nextval('public.products_razopayidmaps_id_seq'::regclass);


--
-- Name: products_razorpayhistory id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_razorpayhistory ALTER COLUMN id SET DEFAULT nextval('public.products_razorpayhistory_id_seq'::regclass);


--
-- Name: products_referalcodes id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalcodes ALTER COLUMN id SET DEFAULT nextval('public.products_referalcodes_id_seq'::regclass);


--
-- Name: products_referalpricelist id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalpricelist ALTER COLUMN id SET DEFAULT nextval('public.products_referalpricelist_id_seq'::regclass);


--
-- Name: products_relatedproducts id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_relatedproducts ALTER COLUMN id SET DEFAULT nextval('public.products_relatedproducts_id_seq'::regclass);


--
-- Name: products_shoplinks id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_shoplinks ALTER COLUMN id SET DEFAULT nextval('public.products_shoplinks_id_seq'::regclass);


--
-- Name: products_similarproducts id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_similarproducts ALTER COLUMN id SET DEFAULT nextval('public.products_similarproducts_id_seq'::regclass);


--
-- Name: products_tags id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_tags ALTER COLUMN id SET DEFAULT nextval('public.products_tags_id_seq'::regclass);


--
-- Name: products_thumbnail id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_thumbnail ALTER COLUMN id SET DEFAULT nextval('public.products_thumbnail_id_seq'::regclass);


--
-- Name: products_usercode id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_usercode ALTER COLUMN id SET DEFAULT nextval('public.products_usercode_id_seq'::regclass);


--
-- Name: products_waitlist id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_waitlist ALTER COLUMN id SET DEFAULT nextval('public.products_waitlist_id_seq'::regclass);


--
-- Name: products_zipcodes id; Type: DEFAULT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_zipcodes ALTER COLUMN id SET DEFAULT nextval('public.products_zipcodes_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3433.dat';

--
-- Data for Name: background_task; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.background_task (id, task_name, task_params, task_hash, verbose_name, priority, run_at, repeat, repeat_until, queue, attempts, failed_at, last_error, locked_by, locked_at, creator_object_id, creator_content_type_id) FROM stdin;
\.
COPY public.background_task (id, task_name, task_params, task_hash, verbose_name, priority, run_at, repeat, repeat_until, queue, attempts, failed_at, last_error, locked_by, locked_at, creator_object_id, creator_content_type_id) FROM '$$PATH$$/3435.dat';

--
-- Data for Name: background_task_completedtask; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.background_task_completedtask (id, task_name, task_params, task_hash, verbose_name, priority, run_at, repeat, repeat_until, queue, attempts, failed_at, last_error, locked_by, locked_at, creator_object_id, creator_content_type_id) FROM stdin;
\.
COPY public.background_task_completedtask (id, task_name, task_params, task_hash, verbose_name, priority, run_at, repeat, repeat_until, queue, attempts, failed_at, last_error, locked_by, locked_at, creator_object_id, creator_content_type_id) FROM '$$PATH$$/3436.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3441.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3443.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: lazysignup_lazyuser; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.lazysignup_lazyuser (id, created, user_id) FROM stdin;
\.
COPY public.lazysignup_lazyuser (id, created, user_id) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: myapp_downloadsmodel; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.myapp_downloadsmodel (id, slug, title, big_title, windows_link, ubuntu_link, mac_link, updated, created) FROM stdin;
\.
COPY public.myapp_downloadsmodel (id, slug, title, big_title, windows_link, ubuntu_link, mac_link, updated, created) FROM '$$PATH$$/3446.dat';

--
-- Data for Name: products_blog; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_blog (id, slug, name, markdown, html, short_html, short_markdown, description, rank, is_published, created, updated, keywords) FROM stdin;
\.
COPY public.products_blog (id, slug, name, markdown, html, short_html, short_markdown, description, rank, is_published, created, updated, keywords) FROM '$$PATH$$/3448.dat';

--
-- Data for Name: products_blogphotos; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_blogphotos (id, image, created, blog_id_id, main_image) FROM stdin;
\.
COPY public.products_blogphotos (id, image, created, blog_id_id, main_image) FROM '$$PATH$$/3450.dat';

--
-- Data for Name: products_breadcrumbs; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_breadcrumbs (id, name, google_product_taxonomy) FROM stdin;
\.
COPY public.products_breadcrumbs (id, name, google_product_taxonomy) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: products_breadentry; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_breadentry (id, rank, created, bread_id_id, link_id_id) FROM stdin;
\.
COPY public.products_breadentry (id, rank, created, bread_id_id, link_id_id) FROM '$$PATH$$/3454.dat';

--
-- Data for Name: products_cart; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_cart (id, created, cart_state, address_name, address1, address2, district, state, zipcode, mobile, paymode, user_id_id, to_be_order_id, payment_amount, is_referal_activated, referal_code, referal_obj_id, ip_data, email_id) FROM stdin;
\.
COPY public.products_cart (id, created, cart_state, address_name, address1, address2, district, state, zipcode, mobile, paymode, user_id_id, to_be_order_id, payment_amount, is_referal_activated, referal_code, referal_obj_id, ip_data, email_id) FROM '$$PATH$$/3456.dat';

--
-- Data for Name: products_cartobjects; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_cartobjects (id, quantity, created, cart_id_id, prod_id_id) FROM stdin;
\.
COPY public.products_cartobjects (id, quantity, created, cart_id_id, prod_id_id) FROM '$$PATH$$/3458.dat';

--
-- Data for Name: products_forgorpwdlink; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_forgorpwdlink (id, code, created, user_id_id) FROM stdin;
\.
COPY public.products_forgorpwdlink (id, code, created, user_id_id) FROM '$$PATH$$/3460.dat';

--
-- Data for Name: products_homepage; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_homepage (id, rank, prod_id_id) FROM stdin;
\.
COPY public.products_homepage (id, rank, prod_id_id) FROM '$$PATH$$/3462.dat';

--
-- Data for Name: products_image; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_image (id, image, created, prod_id_id) FROM stdin;
\.
COPY public.products_image (id, image, created, prod_id_id) FROM '$$PATH$$/3464.dat';

--
-- Data for Name: products_imagedata; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_imagedata (id, rank, img_id_id, prod_id_id, th_home_id, th_micro_id, th_mini_id) FROM stdin;
\.
COPY public.products_imagedata (id, rank, img_id_id, prod_id_id, th_home_id, th_micro_id, th_mini_id) FROM '$$PATH$$/3466.dat';

--
-- Data for Name: products_keywordtags; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_keywordtags (id, name, count) FROM stdin;
\.
COPY public.products_keywordtags (id, name, count) FROM '$$PATH$$/3468.dat';

--
-- Data for Name: products_mainimage; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_mainimage (id, img_data_id, prod_id_id, thumb_data_id) FROM stdin;
\.
COPY public.products_mainimage (id, img_data_id, prod_id_id, thumb_data_id) FROM '$$PATH$$/3470.dat';

--
-- Data for Name: products_orderproducts; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_orderproducts (id, quantity, price, order_id_id, prod_id_id) FROM stdin;
\.
COPY public.products_orderproducts (id, quantity, price, order_id_id, prod_id_id) FROM '$$PATH$$/3472.dat';

--
-- Data for Name: products_orders; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_orders (id, order_id, created, order_state, paymode, delivery_charge, extra_charge, total_amount, courier, tracking_no, address_name, address1, address2, district, state, zipcode, mobile, user_id_id, email_sent_confirm, email_sent_delivered, email_sent_shipped, referal_code, ip_data, email_id) FROM stdin;
\.
COPY public.products_orders (id, order_id, created, order_state, paymode, delivery_charge, extra_charge, total_amount, courier, tracking_no, address_name, address1, address2, district, state, zipcode, mobile, user_id_id, email_sent_confirm, email_sent_delivered, email_sent_shipped, referal_code, ip_data, email_id) FROM '$$PATH$$/3474.dat';

--
-- Data for Name: products_paytmhistory; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_paytmhistory (id, txn_amount, txn_date, txn_id, status, paytm_orderid, order_id, currency, created, user_id_id) FROM stdin;
\.
COPY public.products_paytmhistory (id, txn_amount, txn_date, txn_id, status, paytm_orderid, order_id, currency, created, user_id_id) FROM '$$PATH$$/3476.dat';

--
-- Data for Name: products_product; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_product (id, name, slug, pagetitle, cardtitle, price, mrp_price, quantity_available, in_stock, is_published, created, rank, updated, description, sku, free_delivery, amazon_link, is_amazon, is_google, meta_title, product_head, breadcrumb_id, hide_description, keywords, hide_shop, shopping_description) FROM stdin;
\.
COPY public.products_product (id, name, slug, pagetitle, cardtitle, price, mrp_price, quantity_available, in_stock, is_published, created, rank, updated, description, sku, free_delivery, amazon_link, is_amazon, is_google, meta_title, product_head, breadcrumb_id, hide_description, keywords, hide_shop, shopping_description) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: products_productbullets; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_productbullets (id, data, rank, created, prod_id_id) FROM stdin;
\.
COPY public.products_productbullets (id, data, rank, created, prod_id_id) FROM '$$PATH$$/3480.dat';

--
-- Data for Name: products_productdetails; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_productdetails (id, rank, name, html, prod_id_id) FROM stdin;
\.
COPY public.products_productdetails (id, rank, name, html, prod_id_id) FROM '$$PATH$$/3482.dat';

--
-- Data for Name: products_productkeywords; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_productkeywords (id, rank, created, keytag_id_id, prod_id_id) FROM stdin;
\.
COPY public.products_productkeywords (id, rank, created, keytag_id_id, prod_id_id) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: products_productlinks; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_productlinks (id, rank, created, link_id_id, prod_id_id) FROM stdin;
\.
COPY public.products_productlinks (id, rank, created, link_id_id, prod_id_id) FROM '$$PATH$$/3486.dat';

--
-- Data for Name: products_producttags; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_producttags (id, prod_id_id, tag_id_id) FROM stdin;
\.
COPY public.products_producttags (id, prod_id_id, tag_id_id) FROM '$$PATH$$/3488.dat';

--
-- Data for Name: products_razopayidmaps; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_razopayidmaps (id, rp_id, order_id, created) FROM stdin;
\.
COPY public.products_razopayidmaps (id, rp_id, order_id, created) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: products_razorpayhistory; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_razorpayhistory (id, order_id, txn_amount, txn_date, status, details, created, user_id_id) FROM stdin;
\.
COPY public.products_razorpayhistory (id, order_id, txn_amount, txn_date, status, details, created, user_id_id) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: products_referalcodes; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_referalcodes (id, code, is_active, referer, details, is_shipping_free, created) FROM stdin;
\.
COPY public.products_referalcodes (id, code, is_active, referer, details, is_shipping_free, created) FROM '$$PATH$$/3494.dat';

--
-- Data for Name: products_referalpricelist; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_referalpricelist (id, price, moq, code_id_id, prod_id_id) FROM stdin;
\.
COPY public.products_referalpricelist (id, price, moq, code_id_id, prod_id_id) FROM '$$PATH$$/3496.dat';

--
-- Data for Name: products_relatedproducts; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_relatedproducts (id, rank, prod_id_id, sim_id_id) FROM stdin;
\.
COPY public.products_relatedproducts (id, rank, prod_id_id, sim_id_id) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: products_shoplinks; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_shoplinks (id, url, created, tag_id_id, rank, meta_description, meta_title, name, breadcrumb_id) FROM stdin;
\.
COPY public.products_shoplinks (id, url, created, tag_id_id, rank, meta_description, meta_title, name, breadcrumb_id) FROM '$$PATH$$/3500.dat';

--
-- Data for Name: products_similarproducts; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_similarproducts (id, rank, prod_id_id, sim_id_id) FROM stdin;
\.
COPY public.products_similarproducts (id, rank, prod_id_id, sim_id_id) FROM '$$PATH$$/3502.dat';

--
-- Data for Name: products_tags; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_tags (id, name, rank, type, is_standalone, parent_id) FROM stdin;
\.
COPY public.products_tags (id, name, rank, type, is_standalone, parent_id) FROM '$$PATH$$/3504.dat';

--
-- Data for Name: products_thumbnail; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_thumbnail (id, image, created, img_id_id) FROM stdin;
\.
COPY public.products_thumbnail (id, image, created, img_id_id) FROM '$$PATH$$/3506.dat';

--
-- Data for Name: products_usercode; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_usercode (id, code, user_id_id, mobile, ip_data) FROM stdin;
\.
COPY public.products_usercode (id, code, user_id_id, mobile, ip_data) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: products_waitlist; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_waitlist (id, created, prod_id_id, user_id_id) FROM stdin;
\.
COPY public.products_waitlist (id, created, prod_id_id, user_id_id) FROM '$$PATH$$/3510.dat';

--
-- Data for Name: products_zipcodes; Type: TABLE DATA; Schema: public; Owner: noobuser
--

COPY public.products_zipcodes (id, zipcode, district, state) FROM stdin;
\.
COPY public.products_zipcodes (id, zipcode, district, state) FROM '$$PATH$$/3512.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 7, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 172, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 422, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: background_task_completedtask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.background_task_completedtask_id_seq', 132, true);


--
-- Name: background_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.background_task_id_seq', 133, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1204, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 43, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 112, true);


--
-- Name: lazysignup_lazyuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.lazysignup_lazyuser_id_seq', 1, true);


--
-- Name: myapp_downloadsmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.myapp_downloadsmodel_id_seq', 1, true);


--
-- Name: products_blog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_blog_id_seq', 4, true);


--
-- Name: products_blogphotos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_blogphotos_id_seq', 12, true);


--
-- Name: products_breadcrumbs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_breadcrumbs_id_seq', 7, true);


--
-- Name: products_breadentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_breadentry_id_seq', 11, true);


--
-- Name: products_cart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_cart_id_seq', 396, true);


--
-- Name: products_cartobjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_cartobjects_id_seq', 717, true);


--
-- Name: products_forgorpwdlink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_forgorpwdlink_id_seq', 11, true);


--
-- Name: products_homepage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_homepage_id_seq', 5, true);


--
-- Name: products_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_image_id_seq', 55, true);


--
-- Name: products_imagedata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_imagedata_id_seq', 54, true);


--
-- Name: products_keywordtags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_keywordtags_id_seq', 8, true);


--
-- Name: products_mainimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_mainimage_id_seq', 32, true);


--
-- Name: products_orderproducts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_orderproducts_id_seq', 158, true);


--
-- Name: products_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_orders_id_seq', 136, true);


--
-- Name: products_paytmhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_paytmhistory_id_seq', 28, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_product_id_seq', 32, true);


--
-- Name: products_productbullets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_productbullets_id_seq', 45, true);


--
-- Name: products_productdetails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_productdetails_id_seq', 45, true);


--
-- Name: products_productkeywords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_productkeywords_id_seq', 27, true);


--
-- Name: products_productlinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_productlinks_id_seq', 12, true);


--
-- Name: products_producttags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_producttags_id_seq', 48, true);


--
-- Name: products_razopayidmaps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_razopayidmaps_id_seq', 55, true);


--
-- Name: products_razorpayhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_razorpayhistory_id_seq', 19, true);


--
-- Name: products_referalcodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_referalcodes_id_seq', 1, true);


--
-- Name: products_referalpricelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_referalpricelist_id_seq', 1, true);


--
-- Name: products_relatedproducts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_relatedproducts_id_seq', 21, true);


--
-- Name: products_shoplinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_shoplinks_id_seq', 8, true);


--
-- Name: products_similarproducts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_similarproducts_id_seq', 31, true);


--
-- Name: products_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_tags_id_seq', 20, true);


--
-- Name: products_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_thumbnail_id_seq', 162, true);


--
-- Name: products_usercode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_usercode_id_seq', 422, true);


--
-- Name: products_waitlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_waitlist_id_seq', 4, true);


--
-- Name: products_zipcodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: noobuser
--

SELECT pg_catalog.setval('public.products_zipcodes_id_seq', 19093, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: background_task_completedtask background_task_completedtask_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.background_task_completedtask
    ADD CONSTRAINT background_task_completedtask_pkey PRIMARY KEY (id);


--
-- Name: background_task background_task_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.background_task
    ADD CONSTRAINT background_task_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: lazysignup_lazyuser lazysignup_lazyuser_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.lazysignup_lazyuser
    ADD CONSTRAINT lazysignup_lazyuser_pkey PRIMARY KEY (id);


--
-- Name: lazysignup_lazyuser lazysignup_lazyuser_user_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.lazysignup_lazyuser
    ADD CONSTRAINT lazysignup_lazyuser_user_id_key UNIQUE (user_id);


--
-- Name: myapp_downloadsmodel myapp_downloadsmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.myapp_downloadsmodel
    ADD CONSTRAINT myapp_downloadsmodel_pkey PRIMARY KEY (id);


--
-- Name: myapp_downloadsmodel myapp_downloadsmodel_slug_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.myapp_downloadsmodel
    ADD CONSTRAINT myapp_downloadsmodel_slug_key UNIQUE (slug);


--
-- Name: products_blog products_blog_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_blog
    ADD CONSTRAINT products_blog_pkey PRIMARY KEY (id);


--
-- Name: products_blog products_blog_slug_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_blog
    ADD CONSTRAINT products_blog_slug_key UNIQUE (slug);


--
-- Name: products_blogphotos products_blogphotos_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_blogphotos
    ADD CONSTRAINT products_blogphotos_pkey PRIMARY KEY (id);


--
-- Name: products_breadcrumbs products_breadcrumbs_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_breadcrumbs
    ADD CONSTRAINT products_breadcrumbs_pkey PRIMARY KEY (id);


--
-- Name: products_breadentry products_breadentry_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_breadentry
    ADD CONSTRAINT products_breadentry_pkey PRIMARY KEY (id);


--
-- Name: products_cart products_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_pkey PRIMARY KEY (id);


--
-- Name: products_cart products_cart_user_id_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_user_id_id_key UNIQUE (user_id_id);


--
-- Name: products_cartobjects products_cartobjects_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cartobjects
    ADD CONSTRAINT products_cartobjects_pkey PRIMARY KEY (id);


--
-- Name: products_forgorpwdlink products_forgorpwdlink_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_forgorpwdlink
    ADD CONSTRAINT products_forgorpwdlink_pkey PRIMARY KEY (id);


--
-- Name: products_homepage products_homepage_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_homepage
    ADD CONSTRAINT products_homepage_pkey PRIMARY KEY (id);


--
-- Name: products_homepage products_homepage_prod_id_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_homepage
    ADD CONSTRAINT products_homepage_prod_id_id_key UNIQUE (prod_id_id);


--
-- Name: products_image products_image_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT products_image_pkey PRIMARY KEY (id);


--
-- Name: products_imagedata products_imagedata_img_id_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_img_id_id_key UNIQUE (img_id_id);


--
-- Name: products_imagedata products_imagedata_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_pkey PRIMARY KEY (id);


--
-- Name: products_keywordtags products_keywordtags_name_d777d86d_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_keywordtags
    ADD CONSTRAINT products_keywordtags_name_d777d86d_uniq UNIQUE (name);


--
-- Name: products_keywordtags products_keywordtags_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_keywordtags
    ADD CONSTRAINT products_keywordtags_pkey PRIMARY KEY (id);


--
-- Name: products_mainimage products_mainimage_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_mainimage
    ADD CONSTRAINT products_mainimage_pkey PRIMARY KEY (id);


--
-- Name: products_mainimage products_mainimage_prod_id_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_mainimage
    ADD CONSTRAINT products_mainimage_prod_id_id_key UNIQUE (prod_id_id);


--
-- Name: products_orderproducts products_orderproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orderproducts
    ADD CONSTRAINT products_orderproducts_pkey PRIMARY KEY (id);


--
-- Name: products_orders products_orders_order_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orders
    ADD CONSTRAINT products_orders_order_id_key UNIQUE (order_id);


--
-- Name: products_orders products_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orders
    ADD CONSTRAINT products_orders_pkey PRIMARY KEY (id);


--
-- Name: products_paytmhistory products_paytmhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_paytmhistory
    ADD CONSTRAINT products_paytmhistory_pkey PRIMARY KEY (id);


--
-- Name: products_product products_product_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_pkey PRIMARY KEY (id);


--
-- Name: products_product products_product_sku_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_sku_key UNIQUE (sku);


--
-- Name: products_product products_product_slug_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_slug_key UNIQUE (slug);


--
-- Name: products_productbullets products_productbullets_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productbullets
    ADD CONSTRAINT products_productbullets_pkey PRIMARY KEY (id);


--
-- Name: products_productdetails products_productdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productdetails
    ADD CONSTRAINT products_productdetails_pkey PRIMARY KEY (id);


--
-- Name: products_productkeywords products_productkeywords_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productkeywords
    ADD CONSTRAINT products_productkeywords_pkey PRIMARY KEY (id);


--
-- Name: products_productkeywords products_productkeywords_prod_id_id_keytag_id_id_22ef94d0_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productkeywords
    ADD CONSTRAINT products_productkeywords_prod_id_id_keytag_id_id_22ef94d0_uniq UNIQUE (prod_id_id, keytag_id_id);


--
-- Name: products_productlinks products_productlinks_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productlinks
    ADD CONSTRAINT products_productlinks_pkey PRIMARY KEY (id);


--
-- Name: products_producttags products_producttags_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_producttags
    ADD CONSTRAINT products_producttags_pkey PRIMARY KEY (id);


--
-- Name: products_producttags products_producttags_prod_id_id_tag_id_id_4fd493b9_uniq; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_producttags
    ADD CONSTRAINT products_producttags_prod_id_id_tag_id_id_4fd493b9_uniq UNIQUE (prod_id_id, tag_id_id);


--
-- Name: products_razopayidmaps products_razopayidmaps_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_razopayidmaps
    ADD CONSTRAINT products_razopayidmaps_pkey PRIMARY KEY (id);


--
-- Name: products_razorpayhistory products_razorpayhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_razorpayhistory
    ADD CONSTRAINT products_razorpayhistory_pkey PRIMARY KEY (id);


--
-- Name: products_referalcodes products_referalcodes_code_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalcodes
    ADD CONSTRAINT products_referalcodes_code_key UNIQUE (code);


--
-- Name: products_referalcodes products_referalcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalcodes
    ADD CONSTRAINT products_referalcodes_pkey PRIMARY KEY (id);


--
-- Name: products_referalpricelist products_referalpricelist_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalpricelist
    ADD CONSTRAINT products_referalpricelist_pkey PRIMARY KEY (id);


--
-- Name: products_relatedproducts products_relatedproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_relatedproducts
    ADD CONSTRAINT products_relatedproducts_pkey PRIMARY KEY (id);


--
-- Name: products_shoplinks products_shoplinks_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_shoplinks
    ADD CONSTRAINT products_shoplinks_pkey PRIMARY KEY (id);


--
-- Name: products_shoplinks products_shoplinks_url_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_shoplinks
    ADD CONSTRAINT products_shoplinks_url_key UNIQUE (url);


--
-- Name: products_similarproducts products_similarproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_similarproducts
    ADD CONSTRAINT products_similarproducts_pkey PRIMARY KEY (id);


--
-- Name: products_tags products_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_tags
    ADD CONSTRAINT products_tags_pkey PRIMARY KEY (id);


--
-- Name: products_thumbnail products_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_thumbnail
    ADD CONSTRAINT products_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: products_usercode products_usercode_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_usercode
    ADD CONSTRAINT products_usercode_pkey PRIMARY KEY (id);


--
-- Name: products_usercode products_usercode_user_id_id_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_usercode
    ADD CONSTRAINT products_usercode_user_id_id_key UNIQUE (user_id_id);


--
-- Name: products_waitlist products_waitlist_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_waitlist
    ADD CONSTRAINT products_waitlist_pkey PRIMARY KEY (id);


--
-- Name: products_zipcodes products_zipcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_zipcodes
    ADD CONSTRAINT products_zipcodes_pkey PRIMARY KEY (id);


--
-- Name: products_zipcodes products_zipcodes_zipcode_key; Type: CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_zipcodes
    ADD CONSTRAINT products_zipcodes_zipcode_key UNIQUE (zipcode);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: background_task_attempts_a9ade23d; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_attempts_a9ade23d ON public.background_task USING btree (attempts);


--
-- Name: background_task_completedtask_attempts_772a6783; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_attempts_772a6783 ON public.background_task_completedtask USING btree (attempts);


--
-- Name: background_task_completedtask_creator_content_type_id_21d6a741; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_creator_content_type_id_21d6a741 ON public.background_task_completedtask USING btree (creator_content_type_id);


--
-- Name: background_task_completedtask_failed_at_3de56618; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_failed_at_3de56618 ON public.background_task_completedtask USING btree (failed_at);


--
-- Name: background_task_completedtask_locked_at_29c62708; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_locked_at_29c62708 ON public.background_task_completedtask USING btree (locked_at);


--
-- Name: background_task_completedtask_locked_by_edc8a213; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_locked_by_edc8a213 ON public.background_task_completedtask USING btree (locked_by);


--
-- Name: background_task_completedtask_locked_by_edc8a213_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_locked_by_edc8a213_like ON public.background_task_completedtask USING btree (locked_by varchar_pattern_ops);


--
-- Name: background_task_completedtask_priority_9080692e; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_priority_9080692e ON public.background_task_completedtask USING btree (priority);


--
-- Name: background_task_completedtask_queue_61fb0415; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_queue_61fb0415 ON public.background_task_completedtask USING btree (queue);


--
-- Name: background_task_completedtask_queue_61fb0415_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_queue_61fb0415_like ON public.background_task_completedtask USING btree (queue varchar_pattern_ops);


--
-- Name: background_task_completedtask_run_at_77c80f34; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_run_at_77c80f34 ON public.background_task_completedtask USING btree (run_at);


--
-- Name: background_task_completedtask_task_hash_91187576; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_task_hash_91187576 ON public.background_task_completedtask USING btree (task_hash);


--
-- Name: background_task_completedtask_task_hash_91187576_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_task_hash_91187576_like ON public.background_task_completedtask USING btree (task_hash varchar_pattern_ops);


--
-- Name: background_task_completedtask_task_name_388dabc2; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_task_name_388dabc2 ON public.background_task_completedtask USING btree (task_name);


--
-- Name: background_task_completedtask_task_name_388dabc2_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_completedtask_task_name_388dabc2_like ON public.background_task_completedtask USING btree (task_name varchar_pattern_ops);


--
-- Name: background_task_creator_content_type_id_61cc9af3; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_creator_content_type_id_61cc9af3 ON public.background_task USING btree (creator_content_type_id);


--
-- Name: background_task_failed_at_b81bba14; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_failed_at_b81bba14 ON public.background_task USING btree (failed_at);


--
-- Name: background_task_locked_at_0fb0f225; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_locked_at_0fb0f225 ON public.background_task USING btree (locked_at);


--
-- Name: background_task_locked_by_db7779e3; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_locked_by_db7779e3 ON public.background_task USING btree (locked_by);


--
-- Name: background_task_locked_by_db7779e3_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_locked_by_db7779e3_like ON public.background_task USING btree (locked_by varchar_pattern_ops);


--
-- Name: background_task_priority_88bdbce9; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_priority_88bdbce9 ON public.background_task USING btree (priority);


--
-- Name: background_task_queue_1d5f3a40; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_queue_1d5f3a40 ON public.background_task USING btree (queue);


--
-- Name: background_task_queue_1d5f3a40_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_queue_1d5f3a40_like ON public.background_task USING btree (queue varchar_pattern_ops);


--
-- Name: background_task_run_at_7baca3aa; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_run_at_7baca3aa ON public.background_task USING btree (run_at);


--
-- Name: background_task_task_hash_d8f233bd; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_task_hash_d8f233bd ON public.background_task USING btree (task_hash);


--
-- Name: background_task_task_hash_d8f233bd_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_task_hash_d8f233bd_like ON public.background_task USING btree (task_hash varchar_pattern_ops);


--
-- Name: background_task_task_name_4562d56a; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_task_name_4562d56a ON public.background_task USING btree (task_name);


--
-- Name: background_task_task_name_4562d56a_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX background_task_task_name_4562d56a_like ON public.background_task USING btree (task_name varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: lazysignup_lazyuser_created_fcd322b5; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX lazysignup_lazyuser_created_fcd322b5 ON public.lazysignup_lazyuser USING btree (created);


--
-- Name: myapp_downloadsmodel_slug_74439d67_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX myapp_downloadsmodel_slug_74439d67_like ON public.myapp_downloadsmodel USING btree (slug varchar_pattern_ops);


--
-- Name: products_blog_slug_2fa9d169_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_blog_slug_2fa9d169_like ON public.products_blog USING btree (slug varchar_pattern_ops);


--
-- Name: products_blogphotos_blog_id_id_094c32b3; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_blogphotos_blog_id_id_094c32b3 ON public.products_blogphotos USING btree (blog_id_id);


--
-- Name: products_breadentry_bread_id_id_5c54599d; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_breadentry_bread_id_id_5c54599d ON public.products_breadentry USING btree (bread_id_id);


--
-- Name: products_breadentry_link_id_id_b5071704; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_breadentry_link_id_id_b5071704 ON public.products_breadentry USING btree (link_id_id);


--
-- Name: products_cart_referal_obj_id_09c8c88b; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_cart_referal_obj_id_09c8c88b ON public.products_cart USING btree (referal_obj_id);


--
-- Name: products_cartobjects_cart_id_id_3e624781; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_cartobjects_cart_id_id_3e624781 ON public.products_cartobjects USING btree (cart_id_id);


--
-- Name: products_cartobjects_prod_id_id_47afcb53; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_cartobjects_prod_id_id_47afcb53 ON public.products_cartobjects USING btree (prod_id_id);


--
-- Name: products_forgorpwdlink_user_id_id_dcb662b7; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_forgorpwdlink_user_id_id_dcb662b7 ON public.products_forgorpwdlink USING btree (user_id_id);


--
-- Name: products_image_prod_id_id_c2143108; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_image_prod_id_id_c2143108 ON public.products_image USING btree (prod_id_id);


--
-- Name: products_imagedata_prod_id_id_d763bcc2; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_imagedata_prod_id_id_d763bcc2 ON public.products_imagedata USING btree (prod_id_id);


--
-- Name: products_imagedata_th_home_id_e22c98fe; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_imagedata_th_home_id_e22c98fe ON public.products_imagedata USING btree (th_home_id);


--
-- Name: products_imagedata_th_micro_id_cff4fc99; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_imagedata_th_micro_id_cff4fc99 ON public.products_imagedata USING btree (th_micro_id);


--
-- Name: products_imagedata_th_mini_id_7608c9c9; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_imagedata_th_mini_id_7608c9c9 ON public.products_imagedata USING btree (th_mini_id);


--
-- Name: products_keywordtags_name_d777d86d_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_keywordtags_name_d777d86d_like ON public.products_keywordtags USING btree (name varchar_pattern_ops);


--
-- Name: products_mainimage_img_data_id_5808a737; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_mainimage_img_data_id_5808a737 ON public.products_mainimage USING btree (img_data_id);


--
-- Name: products_mainimage_thumb_data_id_356b1162; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_mainimage_thumb_data_id_356b1162 ON public.products_mainimage USING btree (thumb_data_id);


--
-- Name: products_orderproducts_order_id_id_69779bb8; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_orderproducts_order_id_id_69779bb8 ON public.products_orderproducts USING btree (order_id_id);


--
-- Name: products_orderproducts_prod_id_id_7714df9b; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_orderproducts_prod_id_id_7714df9b ON public.products_orderproducts USING btree (prod_id_id);


--
-- Name: products_orders_order_id_b28e1457_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_orders_order_id_b28e1457_like ON public.products_orders USING btree (order_id varchar_pattern_ops);


--
-- Name: products_orders_user_id_id_44d0b3dd; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_orders_user_id_id_44d0b3dd ON public.products_orders USING btree (user_id_id);


--
-- Name: products_paytmhistory_user_id_id_bc56ddcf; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_paytmhistory_user_id_id_bc56ddcf ON public.products_paytmhistory USING btree (user_id_id);


--
-- Name: products_product_breadcrumb_id_c7b8d6a3; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_product_breadcrumb_id_c7b8d6a3 ON public.products_product USING btree (breadcrumb_id);


--
-- Name: products_product_sku_3c51a516_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_product_sku_3c51a516_like ON public.products_product USING btree (sku varchar_pattern_ops);


--
-- Name: products_product_slug_70d3148d_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_product_slug_70d3148d_like ON public.products_product USING btree (slug varchar_pattern_ops);


--
-- Name: products_productbullets_prod_id_id_f69ad6ec; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_productbullets_prod_id_id_f69ad6ec ON public.products_productbullets USING btree (prod_id_id);


--
-- Name: products_productdetails_prod_id_id_72d3b635; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_productdetails_prod_id_id_72d3b635 ON public.products_productdetails USING btree (prod_id_id);


--
-- Name: products_productkeywords_keytag_id_id_6a103f7d; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_productkeywords_keytag_id_id_6a103f7d ON public.products_productkeywords USING btree (keytag_id_id);


--
-- Name: products_productkeywords_prod_id_id_f69ce25a; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_productkeywords_prod_id_id_f69ce25a ON public.products_productkeywords USING btree (prod_id_id);


--
-- Name: products_productlinks_link_id_id_16c5ee0c; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_productlinks_link_id_id_16c5ee0c ON public.products_productlinks USING btree (link_id_id);


--
-- Name: products_productlinks_prod_id_id_31f270cf; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_productlinks_prod_id_id_31f270cf ON public.products_productlinks USING btree (prod_id_id);


--
-- Name: products_producttags_prod_id_id_1f91c29d; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_producttags_prod_id_id_1f91c29d ON public.products_producttags USING btree (prod_id_id);


--
-- Name: products_producttags_tag_id_id_69ac9e9f; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_producttags_tag_id_id_69ac9e9f ON public.products_producttags USING btree (tag_id_id);


--
-- Name: products_razorpayhistory_user_id_id_c4e067c9; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_razorpayhistory_user_id_id_c4e067c9 ON public.products_razorpayhistory USING btree (user_id_id);


--
-- Name: products_referalcodes_code_f83351aa_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_referalcodes_code_f83351aa_like ON public.products_referalcodes USING btree (code varchar_pattern_ops);


--
-- Name: products_referalpricelist_code_id_id_e96f2872; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_referalpricelist_code_id_id_e96f2872 ON public.products_referalpricelist USING btree (code_id_id);


--
-- Name: products_referalpricelist_prod_id_id_d4c63e23; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_referalpricelist_prod_id_id_d4c63e23 ON public.products_referalpricelist USING btree (prod_id_id);


--
-- Name: products_relatedproducts_prod_id_id_3572e434; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_relatedproducts_prod_id_id_3572e434 ON public.products_relatedproducts USING btree (prod_id_id);


--
-- Name: products_relatedproducts_sim_id_id_e54af4e0; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_relatedproducts_sim_id_id_e54af4e0 ON public.products_relatedproducts USING btree (sim_id_id);


--
-- Name: products_shoplinks_breadcrumb_id_a0a784d0; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_shoplinks_breadcrumb_id_a0a784d0 ON public.products_shoplinks USING btree (breadcrumb_id);


--
-- Name: products_shoplinks_tag_id_id_2825f4d4; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_shoplinks_tag_id_id_2825f4d4 ON public.products_shoplinks USING btree (tag_id_id);


--
-- Name: products_shoplinks_url_e4f6bc4c_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_shoplinks_url_e4f6bc4c_like ON public.products_shoplinks USING btree (url varchar_pattern_ops);


--
-- Name: products_similarproducts_prod_id_id_b3f0174c; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_similarproducts_prod_id_id_b3f0174c ON public.products_similarproducts USING btree (prod_id_id);


--
-- Name: products_similarproducts_sim_id_id_7eeff2e7; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_similarproducts_sim_id_id_7eeff2e7 ON public.products_similarproducts USING btree (sim_id_id);


--
-- Name: products_tags_parent_id_a3c5d9ad; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_tags_parent_id_a3c5d9ad ON public.products_tags USING btree (parent_id);


--
-- Name: products_thumbnail_img_id_id_a88b3ecf; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_thumbnail_img_id_id_a88b3ecf ON public.products_thumbnail USING btree (img_id_id);


--
-- Name: products_waitlist_prod_id_id_ea68e7c0; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_waitlist_prod_id_id_ea68e7c0 ON public.products_waitlist USING btree (prod_id_id);


--
-- Name: products_waitlist_user_id_id_2344f6b7; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_waitlist_user_id_id_2344f6b7 ON public.products_waitlist USING btree (user_id_id);


--
-- Name: products_zipcodes_zipcode_21e8128c_like; Type: INDEX; Schema: public; Owner: noobuser
--

CREATE INDEX products_zipcodes_zipcode_21e8128c_like ON public.products_zipcodes USING btree (zipcode varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: background_task_completedtask background_task_comp_creator_content_type_21d6a741_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.background_task_completedtask
    ADD CONSTRAINT background_task_comp_creator_content_type_21d6a741_fk_django_co FOREIGN KEY (creator_content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: background_task background_task_creator_content_type_61cc9af3_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.background_task
    ADD CONSTRAINT background_task_creator_content_type_61cc9af3_fk_django_co FOREIGN KEY (creator_content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: lazysignup_lazyuser lazysignup_lazyuser_user_id_4030eee4_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.lazysignup_lazyuser
    ADD CONSTRAINT lazysignup_lazyuser_user_id_4030eee4_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_blogphotos products_blogphotos_blog_id_id_094c32b3_fk_products_blog_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_blogphotos
    ADD CONSTRAINT products_blogphotos_blog_id_id_094c32b3_fk_products_blog_id FOREIGN KEY (blog_id_id) REFERENCES public.products_blog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_breadentry products_breadentry_bread_id_id_5c54599d_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_breadentry
    ADD CONSTRAINT products_breadentry_bread_id_id_5c54599d_fk_products_ FOREIGN KEY (bread_id_id) REFERENCES public.products_breadcrumbs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_breadentry products_breadentry_link_id_id_b5071704_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_breadentry
    ADD CONSTRAINT products_breadentry_link_id_id_b5071704_fk_products_ FOREIGN KEY (link_id_id) REFERENCES public.products_shoplinks(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_cart products_cart_referal_obj_id_09c8c88b_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_referal_obj_id_09c8c88b_fk_products_ FOREIGN KEY (referal_obj_id) REFERENCES public.products_referalcodes(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_cart products_cart_user_id_id_b1d3270d_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cart
    ADD CONSTRAINT products_cart_user_id_id_b1d3270d_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_cartobjects products_cartobjects_cart_id_id_3e624781_fk_products_cart_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cartobjects
    ADD CONSTRAINT products_cartobjects_cart_id_id_3e624781_fk_products_cart_id FOREIGN KEY (cart_id_id) REFERENCES public.products_cart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_cartobjects products_cartobjects_prod_id_id_47afcb53_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_cartobjects
    ADD CONSTRAINT products_cartobjects_prod_id_id_47afcb53_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_forgorpwdlink products_forgorpwdlink_user_id_id_dcb662b7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_forgorpwdlink
    ADD CONSTRAINT products_forgorpwdlink_user_id_id_dcb662b7_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_homepage products_homepage_prod_id_id_e7f94b86_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_homepage
    ADD CONSTRAINT products_homepage_prod_id_id_e7f94b86_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_image products_image_prod_id_id_c2143108_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT products_image_prod_id_id_c2143108_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_imagedata products_imagedata_img_id_id_c2864f2f_fk_products_image_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_img_id_id_c2864f2f_fk_products_image_id FOREIGN KEY (img_id_id) REFERENCES public.products_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_imagedata products_imagedata_prod_id_id_d763bcc2_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_prod_id_id_d763bcc2_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_imagedata products_imagedata_th_home_id_e22c98fe_fk_products_thumbnail_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_th_home_id_e22c98fe_fk_products_thumbnail_id FOREIGN KEY (th_home_id) REFERENCES public.products_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_imagedata products_imagedata_th_micro_id_cff4fc99_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_th_micro_id_cff4fc99_fk_products_ FOREIGN KEY (th_micro_id) REFERENCES public.products_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_imagedata products_imagedata_th_mini_id_7608c9c9_fk_products_thumbnail_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_imagedata
    ADD CONSTRAINT products_imagedata_th_mini_id_7608c9c9_fk_products_thumbnail_id FOREIGN KEY (th_mini_id) REFERENCES public.products_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_mainimage products_mainimage_img_data_id_5808a737_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_mainimage
    ADD CONSTRAINT products_mainimage_img_data_id_5808a737_fk_products_ FOREIGN KEY (img_data_id) REFERENCES public.products_imagedata(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_mainimage products_mainimage_prod_id_id_d70cc8d6_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_mainimage
    ADD CONSTRAINT products_mainimage_prod_id_id_d70cc8d6_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_mainimage products_mainimage_thumb_data_id_356b1162_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_mainimage
    ADD CONSTRAINT products_mainimage_thumb_data_id_356b1162_fk_products_ FOREIGN KEY (thumb_data_id) REFERENCES public.products_imagedata(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_orderproducts products_orderproduc_order_id_id_69779bb8_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orderproducts
    ADD CONSTRAINT products_orderproduc_order_id_id_69779bb8_fk_products_ FOREIGN KEY (order_id_id) REFERENCES public.products_orders(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_orderproducts products_orderproduc_prod_id_id_7714df9b_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orderproducts
    ADD CONSTRAINT products_orderproduc_prod_id_id_7714df9b_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_orders products_orders_user_id_id_44d0b3dd_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_orders
    ADD CONSTRAINT products_orders_user_id_id_44d0b3dd_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_paytmhistory products_paytmhistory_user_id_id_bc56ddcf_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_paytmhistory
    ADD CONSTRAINT products_paytmhistory_user_id_id_bc56ddcf_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product products_product_breadcrumb_id_c7b8d6a3_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_breadcrumb_id_c7b8d6a3_fk_products_ FOREIGN KEY (breadcrumb_id) REFERENCES public.products_breadcrumbs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productbullets products_productbull_prod_id_id_f69ad6ec_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productbullets
    ADD CONSTRAINT products_productbull_prod_id_id_f69ad6ec_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productdetails products_productdeta_prod_id_id_72d3b635_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productdetails
    ADD CONSTRAINT products_productdeta_prod_id_id_72d3b635_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productkeywords products_productkeyw_keytag_id_id_6a103f7d_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productkeywords
    ADD CONSTRAINT products_productkeyw_keytag_id_id_6a103f7d_fk_products_ FOREIGN KEY (keytag_id_id) REFERENCES public.products_keywordtags(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productkeywords products_productkeyw_prod_id_id_f69ce25a_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productkeywords
    ADD CONSTRAINT products_productkeyw_prod_id_id_f69ce25a_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productlinks products_productlink_link_id_id_16c5ee0c_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productlinks
    ADD CONSTRAINT products_productlink_link_id_id_16c5ee0c_fk_products_ FOREIGN KEY (link_id_id) REFERENCES public.products_shoplinks(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_productlinks products_productlink_prod_id_id_31f270cf_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_productlinks
    ADD CONSTRAINT products_productlink_prod_id_id_31f270cf_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_producttags products_producttags_prod_id_id_1f91c29d_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_producttags
    ADD CONSTRAINT products_producttags_prod_id_id_1f91c29d_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_producttags products_producttags_tag_id_id_69ac9e9f_fk_products_tags_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_producttags
    ADD CONSTRAINT products_producttags_tag_id_id_69ac9e9f_fk_products_tags_id FOREIGN KEY (tag_id_id) REFERENCES public.products_tags(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_razorpayhistory products_razorpayhistory_user_id_id_c4e067c9_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_razorpayhistory
    ADD CONSTRAINT products_razorpayhistory_user_id_id_c4e067c9_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_referalpricelist products_referalpric_code_id_id_e96f2872_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalpricelist
    ADD CONSTRAINT products_referalpric_code_id_id_e96f2872_fk_products_ FOREIGN KEY (code_id_id) REFERENCES public.products_referalcodes(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_referalpricelist products_referalpric_prod_id_id_d4c63e23_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_referalpricelist
    ADD CONSTRAINT products_referalpric_prod_id_id_d4c63e23_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_relatedproducts products_relatedprod_prod_id_id_3572e434_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_relatedproducts
    ADD CONSTRAINT products_relatedprod_prod_id_id_3572e434_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_relatedproducts products_relatedprod_sim_id_id_e54af4e0_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_relatedproducts
    ADD CONSTRAINT products_relatedprod_sim_id_id_e54af4e0_fk_products_ FOREIGN KEY (sim_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_shoplinks products_shoplinks_breadcrumb_id_a0a784d0_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_shoplinks
    ADD CONSTRAINT products_shoplinks_breadcrumb_id_a0a784d0_fk_products_ FOREIGN KEY (breadcrumb_id) REFERENCES public.products_breadcrumbs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_shoplinks products_shoplinks_tag_id_id_2825f4d4_fk_products_tags_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_shoplinks
    ADD CONSTRAINT products_shoplinks_tag_id_id_2825f4d4_fk_products_tags_id FOREIGN KEY (tag_id_id) REFERENCES public.products_tags(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_similarproducts products_similarprod_prod_id_id_b3f0174c_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_similarproducts
    ADD CONSTRAINT products_similarprod_prod_id_id_b3f0174c_fk_products_ FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_similarproducts products_similarprod_sim_id_id_7eeff2e7_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_similarproducts
    ADD CONSTRAINT products_similarprod_sim_id_id_7eeff2e7_fk_products_ FOREIGN KEY (sim_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_tags products_tags_parent_id_a3c5d9ad_fk_products_tags_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_tags
    ADD CONSTRAINT products_tags_parent_id_a3c5d9ad_fk_products_tags_id FOREIGN KEY (parent_id) REFERENCES public.products_tags(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_thumbnail products_thumbnail_img_id_id_a88b3ecf_fk_products_image_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_thumbnail
    ADD CONSTRAINT products_thumbnail_img_id_id_a88b3ecf_fk_products_image_id FOREIGN KEY (img_id_id) REFERENCES public.products_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_usercode products_usercode_user_id_id_9cc4f24a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_usercode
    ADD CONSTRAINT products_usercode_user_id_id_9cc4f24a_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_waitlist products_waitlist_prod_id_id_ea68e7c0_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_waitlist
    ADD CONSTRAINT products_waitlist_prod_id_id_ea68e7c0_fk_products_product_id FOREIGN KEY (prod_id_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_waitlist products_waitlist_user_id_id_2344f6b7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: noobuser
--

ALTER TABLE ONLY public.products_waitlist
    ADD CONSTRAINT products_waitlist_user_id_id_2344f6b7_fk_auth_user_id FOREIGN KEY (user_id_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

